#include "reseau.h"

namespace LD
{
    Reseau::Reseau()
    {
    }
}
