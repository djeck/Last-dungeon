#include <iostream>
#include "fond2d.h"


namespace LD
{
    Fond2D::Fond2D()
    {
    }


    bool Fond2D::onEvent(const irr::SEvent &event)
    {
        return false;
    }
}
