#ifndef RESEAU_H
#define RESEAU_H

namespace LD
{
/** @brief interface r�seau */
    class Reseau
    {
    public:
        Reseau();
    };
}

#endif // RESEAU_H
