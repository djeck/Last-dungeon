#include "preferances.h"

namespace LD
{
    Preferances::Preferances()
    {
    }

    void Preferances::save(void)
    {

    }
}
