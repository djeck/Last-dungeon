#include "map.h"

namespace LD
{
    Map::Map()
    {
    }
}
