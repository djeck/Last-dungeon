#include "overevent.h"

namespace LD
{
    OverEvent::OverEvent()
    {
    }


}
